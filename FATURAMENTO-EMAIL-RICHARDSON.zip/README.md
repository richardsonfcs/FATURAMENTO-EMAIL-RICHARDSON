# FATURAMENTO-EMAIL-RICHARDSON

Deploy no Vercel. Use Resend para envio de e-mails via API.

Env vars (Vercel):
- RESEND_API_KEY
- FROM_EMAIL
