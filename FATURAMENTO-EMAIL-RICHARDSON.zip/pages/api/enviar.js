export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Only POST' });
  const { to, subject, html } = req.body || {};
  if (!to || !html) return res.status(400).json({ error: 'Missing to or html' });

  const API_KEY = process.env.RESEND_API_KEY;
  const FROM = process.env.FROM_EMAIL;
  if (!API_KEY || !FROM) return res.status(500).json({ error: 'Missing RESEND_API_KEY or FROM_EMAIL in environment' });

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`
      },
      body: JSON.stringify({
        from: FROM,
        to: [to],
        subject: subject || 'Fatura',
        html
      })
    });
    const data = await response.json();
    if (!response.ok) {
      return res.status(500).json({ error: data });
    }
    return res.status(200).json({ ok: true, id: data.id || null, data });
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}
