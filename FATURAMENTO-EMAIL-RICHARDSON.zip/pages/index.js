import { useState, useEffect } from 'react';

export default function Home(){ 
  const [tipo,setTipo] = useState('cliente');
  const [empresa,setEmpresa] = useState('');
  const [cnpj,setCnpj] = useState('');
  const [valor,setValor] = useState('');
  const [periodo,setPeriodo] = useState('');
  const [contato,setContato] = useState('');
  const [mensagem,setMensagem] = useState('');
  const [html,setHtml] = useState('');
  const [status,setStatus] = useState('');

  useEffect(()=>{
    const d=new Date(); d.setMonth(d.getMonth()-1);
    setPeriodo(d.toLocaleDateString('pt-BR',{month:'long',year:'numeric'}));
  },[]);

  async function gerar(){
    const res = await fetch(`/templates/${tipo}.html`);
    if(!res.ok){ setHtml('Erro ao carregar template'); return; }
    let text = await res.text();
    const v = (Number(valor)||0).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});
    text = text.replace(/{{\s*empresa\s*}}/g,empresa)
               .replace(/{{\s*cnpj\s*}}/g,cnpj)
               .replace(/{{\s*valor\s*}}/g,v)
               .replace(/{{\s*periodo\s*}}/g,periodo)
               .replace(/{{\s*contato\s*}}/g,contato)
               .replace(/{{\s*mensagem\s*}}/g,mensagem);
    setHtml(text);
  }

  async function enviar(){
    if(!html){ setStatus('Gere o HTML antes'); return; }
    if(!contato){ setStatus('Preencha o e-mail do destinatário'); return; }
    setStatus('Enviando...');
    try{
      const res = await fetch('/api/enviar',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ to: contato, subject: 'Fatura / Solicitação de NF', html })
      });
      const data = await res.json();
      if(res.ok) setStatus('Enviado com sucesso: ' + (data.id||''));
      else setStatus('Erro: ' + JSON.stringify(data));
    }catch(e){ setStatus('Erro: ' + e.message) }
  }

  function copiar(){ if(!html) return alert('Gere o HTML antes'); navigator.clipboard.writeText(html); alert('HTML copiado'); }
  function baixar(){ if(!html) return alert('Gere o HTML antes'); const blob=new Blob([html],{type:'text/html'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='email.html'; a.click(); URL.revokeObjectURL(url); }

  return (
    <div className="container">
      <h1>FATURAMENTO - Gerador e Envio de E-mails</h1>
      <label>Template</label>
      <select value={tipo} onChange={e=>setTipo(e.target.value)}>
        <option value="cliente">Fatura para Cliente</option>
        <option value="contabilidade">Solicitação de Nota Fiscal (Contabilidade)</option>
      </select>

      <label>Nome da Empresa</label>
      <input value={empresa} onChange={e=>setEmpresa(e.target.value)} placeholder="Ex: Emcare Saúde" />

      <label>CNPJ</label>
      <input value={cnpj} onChange={e=>setCnpj(e.target.value)} placeholder="Ex: 50.686.946/0001-21" />

      <label>Valor total (R$)</label>
      <input value={valor} onChange={e=>setValor(e.target.value)} placeholder="Ex: 4800.00" type="number" step="0.01" />

      <label>Período de referência</label>
      <input value={periodo} onChange={e=>setPeriodo(e.target.value)} />

      <label>E-mail destinatário</label>
      <input value={contato} onChange={e=>setContato(e.target.value)} placeholder="destinatario@empresa.com" type="email" />

      <label>Mensagem adicional (opcional)</label>
      <textarea value={mensagem} onChange={e=>setMensagem(e.target.value)} rows={3} placeholder="Observações..."></textarea>

      <div className="actions">
        <button onClick={gerar}>Gerar HTML</button>
        <button className="secondary" onClick={copiar}>Copiar HTML</button>
        <button className="secondary" onClick={baixar}>Baixar HTML</button>
        <button onClick={enviar}>Gerar e Enviar</button>
      </div>

      <div className="small">Status: {status}</div>
      <h2>Pré-visualização</h2>
      <iframe className="preview-frame" srcDoc={html}></iframe>
    </div>
  );
}
